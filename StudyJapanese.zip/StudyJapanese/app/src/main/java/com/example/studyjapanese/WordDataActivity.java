package com.example.studyjapanese;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

public class WordDataActivity extends AppCompatActivity {
    private String mWordData;
    private String mMeanData;
    private String mCategoryData;
    private String mExampleData;
    private int mID;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_data);
        TextView tv_word = (TextView) findViewById(R.id.word_data);
        TextView tv_mean = (TextView) findViewById(R.id.mean_data);
        TextView tv_example = (TextView) findViewById(R.id.example_data);
        Intent intent=getIntent();
        mID=intent.getIntExtra("dataID",0);
        mWordData = intent.getStringExtra("wordData");
        mMeanData = intent.getStringExtra("meanData");
        mExampleData= intent.getStringExtra("exampleData");
        mCategoryData=intent.getStringExtra("categoryData");

        tv_word.setText(mWordData);
        tv_mean.setText(mMeanData);
        tv_example.setText(mExampleData);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_data, menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.update) {
            Intent updateIntent = new Intent(WordDataActivity.this, UpdateWordActivity.class);
            updateIntent.putExtra("dataID",mID);
            updateIntent.putExtra("wordData", mWordData);
            updateIntent.putExtra("meanData", mMeanData);
            updateIntent.putExtra("categoryData",mCategoryData);
            updateIntent.putExtra("exampleData", mExampleData);
            startActivity(updateIntent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
